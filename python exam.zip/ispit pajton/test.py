import sys
sys.path.insert(0, '/test/ispit/ucitavanje')
sys.path.insert(1, '/test/ispit/obracun')

from ucitavanje_vozne_karte import vozne_karte, ucitaj_karte
from voznja_po_razredima import rasporedi_karte

ucitaj_karte()
print(vozne_karte)
rasporedi_karte()