import sys
import csv
sys.path.insert(0, '/test/ispit/ucitavanje')
from ucitavanje_vozne_karte import vozne_karte, ucitaj_karte

#ucitaj_karte()
#print(vozne_karte)

def rasporedi_karte(naziv_datoteke = "studentske.csv"):
    prvi_razred = []
    drugi_razred = []
    studentske_karte = []
    for karta in vozne_karte:
        if (karta["razred"] == "1"):
            prvi_razred.append(karta)
        elif (karta["razred"] == "2"):
            drugi_razred.append(karta)
    for prvi in prvi_razred:
        if (prvi["povlastica"] == "studentska"):
            studentske_karte.append(prvi)
    for drugi in drugi_razred:
        if (drugi["povlastica"] == "studentska"):
            studentske_karte.append(drugi)

    with open(naziv_datoteke, 'w', encoding = "utf8", newline='') as csvfile:
        fieldnames = ["tip voza","vreme polaska","trajanje","razred","povlastica","broj"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames, delimiter='-')
        writer.writerows(studentske_karte)