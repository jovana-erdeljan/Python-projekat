import csv

vozne_karte = []

def ucitaj_karte():
    fieldnames = ["tip voza","vreme polaska","trajanje","razred","povlastica","broj"]
    with open("/test/ispit/ucitavanje/karte.csv",'r', encoding = "utf8") as data:
        for line in csv.DictReader(data, fieldnames=fieldnames):
            vozne_karte.append(line)
        